﻿Install required packages
The provided requirements.txt file can be used to install all the required packages. Use the following command


1. Run cmd from the direcorty where you downloaded file.
2. type pip install –r requirements.txt
3. Run Automation Anywhere task pass python script one at a time in prompt box.
4. All Videos are available in Video folder, You can check solution video and all running scenario videos.
5. Employee Chatbot is available in Chatbot Folder.
6. If You want you can run all python files seperately by going inside folders and i kept readme files there for them.

