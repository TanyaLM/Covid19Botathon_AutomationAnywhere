Keep No of people video in No of people code after creating Video Folder.
Keep Vid_short.mp4 inside SocialDistancing Folder.